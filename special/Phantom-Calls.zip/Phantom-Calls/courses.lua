smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 PENGUIN PROMENADE"), ("GUARDIAN OF THE TOWER"),
    ("ARMY OF THE MUTANTS"), ("ARTISTIC TOWER JUMPING"), ("FINANCIAL BLESSING"), ("HIDDEN HOUSE RESIDENT"),
    ("PROBLEMATIC SWITCH"))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 2 SUGARSWEET BAKERY"), ("SUGAR SHOCK"), ("THE ART OF DOUGH"),
    ("QUALITY CONTROL"), ("FUN IN THE OVEN"), ("DIVE FLIGHT"), ("?"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 3 SILENT CISTERN"), ("ENJOY THE CALM"), ("GUARDED SANCTUARY"),
    ("HYDRODYNAMIC CAGE"), ("BOXES AND TREASURE"), ("THE MYSTERIOUS DOOR'S SECRET"), ("NO PLACE FOR NON-SWIMMERS"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 4 BRIZZBREAK INDUSTRIES"), ("SANTA'S LEGACY"),
    ("CLOCK POINTER DANCE"), ("CHRISTMAS THIEF"), ("GOOMBA EXPRESS"), ("RUINATED TREASURE HUNT"),
    ("SHOWDOWN WITH SANTA CLAUS"))

smlua_text_utils_secret_star_replace(COURSE_BITDW, ("   KOOPA'S UNDERGROUND DUNGEON"))
smlua_text_utils_secret_star_replace(COURSE_BITS, ("   THE FINAL BATTLE"))
smlua_text_utils_secret_star_replace(COURSE_PSS, ("   FIERY BOILER FINALE"))
smlua_text_utils_secret_star_replace(COURSE_TOTWC, ("   ORACLE OF THE CAPS"))
smlua_text_utils_secret_star_replace(COURSE_WMOTR, ("   A SHOCKING TWIST"))
smlua_text_utils_secret_star_replace(COURSE_SA, ("   NOT SO FIERY BOILER FINALE"))
smlua_text_utils_castle_secret_stars_replace(("CAP DILEMMA AND KOOPA"))
smlua_text_utils_extra_text_replace(0, ("A LITTLE EXTRA STAR"))
