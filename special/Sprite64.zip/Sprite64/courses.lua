smlua_text_utils_course_acts_replace(COURSE_BOB, (" 1 Baldi's Schoolhouse"),	("QUESTION 1"),	("ESCAPE DETENTION"),	("BULLY ITS A BULLY"),	("FIND THE 7 RED NOTEBOOKS"),	("GEt OuT WhILe tOU STilL cAN"),	("A COMPLEX EQUATION"))

smlua_text_utils_course_acts_replace(COURSE_WF, (" 2 Fidget Spinner Heaven"),	("SKY-HIGH SPINNING"),	("SPIN THE 3 STAR SPINNERS"),	("PLATFORMING ON FIDGETY GROUND"),	("WEIGHTY RED COINS"),	("BECOME A TWIRLING WEIGHT"),	("TRICKSHOT UNDER THE LEVEL"))

smlua_text_utils_course_acts_replace(COURSE_JRB, (" 3 Uganda"),	("FIND DE WAY"),	("GET THE EBOLA"),	("YOU DO NOT KNOW DE WAY"),	("KNOCK KNOCK ITS KNUCKLES"),	("SPIT ON THEM SECRETS"),	("SHE IS THE NEW QUEEN"))

smlua_text_utils_course_acts_replace(COURSE_CCM, (" 4 Dongs out for Harambe"),	("MASSIVE DONG OUT"),	("BULLET BILL SHOOTING RANGE"),	("FALL THROUGH THE BARS"),	("SHOOT HARAMBE :(((((("),	("BLOODY RED COINS OF HARAMBE"),	("INTO THE MOUTH"))

smlua_text_utils_course_acts_replace(COURSE_BBH, (" 5 Pennywise's Sewer"),	("SNEAK INTO THE SEWERS"),	("THE SECRETS OF THE SEWER"),	("... ... ..."),	("PLUNGE INTO DARKNESS"),	("RED"),	("ITS OKAY TO HIDE"))

smlua_text_utils_course_acts_replace(COURSE_HMC, (" 6 Pokemon Go"),	("POKEMON GO TO THE POLES"),	("SPIN THE 5 POKESTOPS"),	("POKEMON GO AND DRIVE FAST"),	("FIND THE 8 FIRE POKEMON"),	("CONQUER THE GYM"),	("POKEMON GO TO THE POLLS"))

smlua_text_utils_course_acts_replace(COURSE_LLL, (" 7 LETHAL LAVA LAND"),	("BOIL THE BIG BULLY"),	("BULLY THE BULLIES"),	("8-COIN PUZZLE WITH 15 PIECES"),	("RED-HOT LOG ROLLING"),	("HOT-FOOT-IT INTO THE VOLCANO"),	("ELEVATOR TOUR IN THE VOLCANO"))

smlua_text_utils_course_acts_replace(COURSE_SSL, (" 8 Tilted Towers"),	("CLIMB THE TILTED TOWER"),	("PATH TO SHIFTY SHAFTS"),	("ATOP THE TALLEST BUILDING"),	("RED RARITY CRATES"),	("CANNON TO CLOCK TOWER"),	("THANK THE BUS DRIVER"))

smlua_text_utils_course_acts_replace(COURSE_DDD, (" 9 DIRE, DIRE DOCKS"),	("BOARD BOWSER'S SUB"),	("CHESTS IN THE CURRENT"),	("POLE-JUMPING FOR RED COINS"),	("THROUGH THE JET STREAM"),	("THE MANTA RAY'S REWARD"),	("COLLECT THE CAPS..."))

smlua_text_utils_course_acts_replace(COURSE_SL, ("10 SNOWMAN'S LAND"),	("SNOWMAN'S BIG HEAD"),	("CHILL WITH THE BULLY"),	("IN THE DEEP FREEZE"),	("WHIRL FROM THE FREEZING POND"),	("SHELL SHREDDIN' FOR RED COINS"),	("INTO THE IGLOO"))

smlua_text_utils_course_acts_replace(COURSE_WDW, ("11 WET-DRY WORLD"),	("SHOCKING ARROW LIFTS!"),	("TOP O' THE TOWN"),	("SECRETS IN THE SHALLOWS & SKY"),	("EXPRESS ELEVATOR--HURRY UP!"),	("GO TO TOWN FOR RED COINS"),	("QUICK RACE THROUGH DOWNTOWN!"))

smlua_text_utils_course_acts_replace(COURSE_TTM, ("12 TALL, TALL MOUNTAIN"),	("SCALE THE MOUNTAIN"),	("MYSTERY OF THE MONKEY CAGE"),	("SCARY 'SHROOMS, RED COINS"),	("MYSTERIOUS MOUNTAINSIDE"),	("BREATHTAKING VIEW FROM BRIDGE"),	("BLAST TO THE LONELY MUSHROOM"))

smlua_text_utils_course_acts_replace(COURSE_THI, ("13 Revenge on Simple"),	("CLIMB BUP BOI"),	("THE MIGHTY PLUMBER"),	("BLJ THWOMPS COCK (THE SEQUEL)"),	("BAITED RED COINS"),	("SECRET STAR"),	("HOW TO GET BANNED ON SIMPS DISCORD"))

smlua_text_utils_course_acts_replace(COURSE_TTC, ("14 TICK TOCK CLOCK"),	("ROLL INTO THE CAGE"),	("THE PIT AND THE PENDULUMS"),	("GET A HAND"),	("STOMP ON THE THWOMP"),	("TIMED JUMPS ON MOVING BARS"),	("STOP TIME FOR RED COINS"))

smlua_text_utils_course_acts_replace(COURSE_RR, ("15 RAINBOW RIDE"),	("CRUISER CROSSING THE RAINBOW"),	("THE BIG HOUSE IN THE SKY"),	("COINS AMASSED IN A MAZE"),	("SWINGIN' IN THE BREEZE"),	("TRICKY TRIANGLES!"),	("SOMEWHERE OVER THE RAINBOW"))

smlua_text_utils_secret_star_replace(15 + 1, ("   Shrek sings All star"))
smlua_text_utils_secret_star_replace(16 + 1, ("   BOWSER IN THE FIRE SEA"))
smlua_text_utils_secret_star_replace(17 + 1, ("   BOWSER IN THE SKY"))
smlua_text_utils_secret_star_replace(18 + 1, ("   Miner Parkour"))
smlua_text_utils_secret_star_replace(19 + 1, ("   The Floor is Lava Challenge"))
smlua_text_utils_secret_star_replace(20 + 1, ("   Flappy Bird"))
smlua_text_utils_secret_star_replace(21 + 1, ("   VANISH CAP UNDER THE MOAT"))
smlua_text_utils_secret_star_replace(22 + 1, ("   LARGE SPRITE CRANBERRY"))
smlua_text_utils_secret_star_replace(23 + 1, ("   THE SECRET AQUARIUM"))
smlua_text_utils_secret_star_replace(24 + 1, (""))
smlua_text_utils_castle_secret_stars_replace(("   ALL STARS"))
smlua_text_utils_extra_text_replace(0,("OFFER SOMEONE A SPRITE CRANBERERY"))
smlua_text_utils_extra_text_replace(1,(""))
smlua_text_utils_extra_text_replace(2,(""))
smlua_text_utils_extra_text_replace(3,(""))
smlua_text_utils_extra_text_replace(4,(""))
smlua_text_utils_extra_text_replace(5,(""))
smlua_text_utils_extra_text_replace(6,(""))
