#ifndef FlipBlock_MOP_FlipBlock_MOP_model_HEADER_H
#define FlipBlock_MOP_FlipBlock_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_FlipBlock_MOP_0x5f0810[];
extern Vtx VB_FlipBlock_MOP_0x5f0900[];
extern Vtx VB_FlipBlock_MOP_0x5f09f0[];
extern Vtx VB_FlipBlock_MOP_0x5f0ae0[];
extern Vtx VB_FlipBlock_MOP_0x5f0bd0[];
extern Vtx VB_FlipBlock_MOP_0x5f0cc0[];
extern Vtx VB_FlipBlock_MOP_0x5f0db0[];
extern Vtx VB_FlipBlock_MOP_0x5f0ea0[];
extern Vtx VB_FlipBlock_MOP_0x5f0f90[];
extern Vtx VB_FlipBlock_MOP_0x5f1080[];
extern Vtx VB_FlipBlock_MOP_0x5f1170[];
extern Vtx VB_FlipBlock_MOP_0x5f1260[];
extern Vtx VB_FlipBlock_MOP_0x5f1350[];
extern Vtx VB_FlipBlock_MOP_0x5f1440[];
extern Vtx VB_FlipBlock_MOP_0x5f1530[];
extern Vtx VB_FlipBlock_MOP_0x5f1620[];
extern const u8 FlipBlock_MOP__texture_005F0010[];
extern const Light_t Light_FlipBlock_MOP_0x5f0000;
extern const Ambient_t Light_FlipBlock_MOP_0x5f0008;
extern const Gfx DL_FlipBlock_MOP_0x5f1710[];
#endif
