#ifndef Green_Switchboard_Gears_MOP_Green_Switchboard_Gears_MOP_model_HEADER_H
#define Green_Switchboard_Gears_MOP_Green_Switchboard_Gears_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fe750[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fe840[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fe930[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fea20[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5feb10[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fec00[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fecf0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fede0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5feed0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fefc0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff0b0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff1a0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff290[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff380[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff470[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff560[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff650[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff740[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff830[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ff920[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffa10[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffb00[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffbf0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffce0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffdd0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5ffec0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x5fffb0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x6000a0[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x600190[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x600280[];
extern Vtx VB_Green_Switchboard_Gears_MOP_0x600370[];
extern u8 Green_Switchboard_Gears_MOP__texture_005FDF50[];
extern Light_t Light_Green_Switchboard_Gears_MOP_0x5fdf40;
extern Ambient_t Light_Green_Switchboard_Gears_MOP_0x5fdf48;
extern Gfx DL_Green_Switchboard_Gears_MOP_0x600460[];
#endif