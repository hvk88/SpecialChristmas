#ifndef Moving_Rotating_Block_MOP_Moving_Rotating_Block_MOP_model_HEADER_H
#define Moving_Rotating_Block_MOP_Moving_Rotating_Block_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Moving_Rotating_Block_MOP_0x6016b0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6017a0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601890[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601980[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601a70[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601b60[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601c50[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601d40[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601e30[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x601f20[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602010[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602100[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6021f0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6022e0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6023d0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6024c0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6025b0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x6026a0[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602790[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602880[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602970[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602a60[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602b50[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602c40[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602d30[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602e20[];
extern Vtx VB_Moving_Rotating_Block_MOP_0x602f10[];
extern const u8 Moving_Rotating_Block_MOP__texture_006036A0[];
extern const Light_t Light_Moving_Rotating_Block_MOP_0x600ea0;
extern const Ambient_t Light_Moving_Rotating_Block_MOP_0x600ea8;
extern const Gfx DL_Moving_Rotating_Block_MOP_0x603610[];
extern const Gfx DL_Moving_Rotating_Block_MOP_0x603048[];
extern const u8 Moving_Rotating_Block_MOP__texture_00600EB0[];
extern const Gfx DL_Moving_Rotating_Block_MOP_0x603000[];
#endif