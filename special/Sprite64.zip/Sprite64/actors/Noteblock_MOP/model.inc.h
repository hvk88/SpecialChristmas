#ifndef Noteblock_MOP_Noteblock_MOP_model_HEADER_H
#define Noteblock_MOP_Noteblock_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Noteblock_MOP_0x301d7b0[];
extern Vtx VB_Noteblock_MOP_0x301d8a0[];
extern Vtx VB_Noteblock_MOP_0x301d990[];
extern const u8 Noteblock_MOP__texture_0301CFB0[];
extern const Light_t Light_Noteblock_MOP_0x301cfa0;
extern const Ambient_t Light_Noteblock_MOP_0x301cfa8;
extern const Gfx DL_Noteblock_MOP_0x301da80[];
#endif