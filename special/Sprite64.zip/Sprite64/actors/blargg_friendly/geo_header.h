extern const GeoLayout friendly_blargg_geo[];
extern Vtx blargg_friendly_000_offset_mesh_vtx_0[28];
extern Gfx blargg_friendly_000_offset_mesh_tri_0[];
extern Vtx blargg_friendly_000_offset_mesh_vtx_1[6];
extern Gfx blargg_friendly_000_offset_mesh_tri_1[];
extern Vtx blargg_friendly_000_offset_001_mesh_vtx_0[75];
extern Gfx blargg_friendly_000_offset_001_mesh_tri_0[];
extern Vtx blargg_friendly_000_offset_001_mesh_vtx_1[15];
extern Gfx blargg_friendly_000_offset_001_mesh_tri_1[];
extern Vtx blargg_friendly_000_offset_001_mesh_vtx_2[26];
extern Gfx blargg_friendly_000_offset_001_mesh_tri_2[];
extern Vtx blargg_friendly_000_offset_003_mesh_vtx_0[38];
extern Gfx blargg_friendly_000_offset_003_mesh_tri_0[];
extern Vtx blargg_friendly_000_offset_003_mesh_vtx_1[26];
extern Gfx blargg_friendly_000_offset_003_mesh_tri_1[];

extern Gfx blargg_friendly_000_offset_mesh[];
extern Gfx blargg_friendly_000_offset_001_mesh[];
extern Gfx blargg_friendly_000_offset_003_mesh[];
extern Gfx blargg_friendly_material_revert_render_settings[];

