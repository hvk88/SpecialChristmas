#ifndef Spring_MOP_Spring_MOP_model_HEADER_H
#define Spring_MOP_Spring_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Spring_MOP_0x301e438[];
extern Vtx VB_Spring_MOP_0x301e528[];
extern Vtx VB_Spring_MOP_0x301e618[];
extern Vtx VB_Spring_MOP_0x301e708[];
extern Vtx VB_Spring_MOP_0x301e7f8[];
extern Vtx VB_Spring_MOP_0x301e8e8[];
extern Vtx VB_Spring_MOP_0x301e9d8[];
extern Vtx VB_Spring_MOP_0x301eac8[];
extern Vtx VB_Spring_MOP_0x301ebb8[];
extern Vtx VB_Spring_MOP_0x301eca8[];
extern Vtx VB_Spring_MOP_0x301ed98[];
extern Vtx VB_Spring_MOP_0x301ee88[];
extern Vtx VB_Spring_MOP_0x301ef78[];
extern Vtx VB_Spring_MOP_0x301f068[];
extern Vtx VB_Spring_MOP_0x301f158[];
extern Vtx VB_Spring_MOP_0x301f248[];
extern Vtx VB_Spring_MOP_0x301f338[];
extern Vtx VB_Spring_MOP_0x301f428[];
extern Vtx VB_Spring_MOP_0x301f518[];
extern Vtx VB_Spring_MOP_0x301f608[];
extern Vtx VB_Spring_MOP_0x301f6f8[];
extern Vtx VB_Spring_MOP_0x301f7e8[];
extern Vtx VB_Spring_MOP_0x301f8d8[];
extern Vtx VB_Spring_MOP_0x301f9c8[];
extern Vtx VB_Spring_MOP_0x301fab8[];
extern Vtx VB_Spring_MOP_0x301fba8[];
extern const u8 Spring_MOP__texture_0301DC38[];
extern const Light_t Light_Spring_MOP_0x301dc28;
extern const Ambient_t Light_Spring_MOP_0x301dc30;
extern const Gfx DL_Spring_MOP_0x301fc98[];
#endif