const GeoLayout Green_Switchboard_MOP[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Green_Switchboard_MOP_0x5fd8b0),
	  GEO_ANIMATED_PART(1, 0, 6, 0, DL_Green_Switchboard_MOP_0x5fd8b0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
