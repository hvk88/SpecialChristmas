#ifndef Green_Switchboard_MOP_Green_Switchboard_MOP_model_HEADER_H
#define Green_Switchboard_MOP_Green_Switchboard_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Green_Switchboard_MOP_0x5fc9b0[];
extern Vtx VB_Green_Switchboard_MOP_0x5fcaa0[];
extern Vtx VB_Green_Switchboard_MOP_0x5fcb90[];
extern Vtx VB_Green_Switchboard_MOP_0x5fcc80[];
extern Vtx VB_Green_Switchboard_MOP_0x5fcd70[];
extern Vtx VB_Green_Switchboard_MOP_0x5fce60[];
extern Vtx VB_Green_Switchboard_MOP_0x5fcf50[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd040[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd130[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd220[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd310[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd400[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd4f0[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd5e0[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd6d0[];
extern Vtx VB_Green_Switchboard_MOP_0x5fd7c0[];
extern u8 Green_Switchboard_MOP__texture_005FC1B0[];
extern Light_t Light_Green_Switchboard_MOP_0x5fc1a0;
extern Ambient_t Light_Green_Switchboard_MOP_0x5fc1a8;
extern Gfx DL_Green_Switchboard_MOP_0x5fd8b0[];
#endif