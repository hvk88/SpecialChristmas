#ifndef Switchblock_Switch_MOP_Switchblock_Switch_MOP_model_HEADER_H
#define Switchblock_Switch_MOP_Switchblock_Switch_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Switchblock_Switch_MOP_0x5f6660[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6750[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6840[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6930[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6a20[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6b10[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6c00[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6cf0[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6de0[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6ed0[];
extern Vtx VB_Switchblock_Switch_MOP_0x5f6fc0[];
extern const u8 Switchblock_Switch_MOP__texture_005F5E60[];
extern const Light_t Light_Switchblock_Switch_MOP_0x5f5e50;
extern const Ambient_t Light_Switchblock_Switch_MOP_0x5f5e58;
extern const Gfx DL_Switchblock_Switch_MOP_0x5f70b0[];
extern const Light_t Light_Switchblock_Switch_MOP_0x5f7578;
extern const Ambient_t Light_Switchblock_Switch_MOP_0x5f757c;
extern const Gfx DL_Switchblock_Switch_MOP_0x5f7580[];
extern const Gfx DL_Switchblock_Switch_MOP_0x5f70f0[];
#endif