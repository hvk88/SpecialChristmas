const GeoLayout Switchblock_Switch_MOP[]= {
GEO_SWITCH_CASE(2, geo_switch_anim_state),
GEO_OPEN_NODE(),
GEO_DISPLAY_LIST(1,DL_Switchblock_Switch_MOP_0x5f70b0),
GEO_DISPLAY_LIST(1,DL_Switchblock_Switch_MOP_0x5f7580),
GEO_CLOSE_NODE(),
GEO_END(),
};
