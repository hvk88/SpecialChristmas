#ifndef Flipswap_Platform_Border_MOP_Flipswap_Platform_Border_MOP_model_HEADER_H
#define Flipswap_Platform_Border_MOP_Flipswap_Platform_Border_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f7de0[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f7ed0[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f7fc0[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f80b0[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f81a0[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f8290[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f8380[];
extern Vtx VB_Flipswap_Platform_Border_MOP_0x5f8470[];
extern u8 Flipswap_Platform_Border_MOP__texture_005F75E0[];
extern Light_t Light_Flipswap_Platform_Border_MOP_0x5f75d0;
extern Ambient_t Light_Flipswap_Platform_Border_MOP_0x5f75d8;
extern Gfx DL_Flipswap_Platform_Border_MOP_0x5f8560[];
#endif