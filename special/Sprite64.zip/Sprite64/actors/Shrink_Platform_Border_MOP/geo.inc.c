const GeoLayout Shrink_Platform_Border_MOP[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
	  GEO_DISPLAY_LIST(LAYER_OPAQUE, DL_Shrink_Platform_Border_MOP_0x3020860),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
