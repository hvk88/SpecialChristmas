#ifndef Shrink_Platform_Border_MOP_Shrink_Platform_Border_MOP_model_HEADER_H
#define Shrink_Platform_Border_MOP_Shrink_Platform_Border_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Shrink_Platform_Border_MOP_0x3020550[];
extern Vtx VB_Shrink_Platform_Border_MOP_0x3020640[];
extern Vtx VB_Shrink_Platform_Border_MOP_0x3020730[];
extern Vtx VB_Shrink_Platform_Border_MOP_0x3020820[];
extern Light_t Light_Shrink_Platform_Border_MOP_0x3020540;
extern Ambient_t Light_Shrink_Platform_Border_MOP_0x3020548;
extern Gfx DL_Shrink_Platform_Border_MOP_0x3020860[];
extern Gfx DL_Shrink_Platform_Border_MOP_0x3021190[];
#endif