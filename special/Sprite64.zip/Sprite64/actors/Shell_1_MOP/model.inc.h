#ifndef Shell_1_MOP_Shell_1_MOP_model_HEADER_H
#define Shell_1_MOP_Shell_1_MOP_model_HEADER_H
#include "types.h"
extern Vtx VB_Shell_1_MOP_0x80263e8[];
extern Vtx VB_Shell_1_MOP_0x80264d8[];
extern Vtx VB_Shell_1_MOP_0x80265c8[];
extern Vtx VB_Shell_1_MOP_0x80266b8[];
extern Vtx VB_Shell_1_MOP_0x80267a8[];
extern Vtx VB_Shell_1_MOP_0x8026898[];
extern Vtx VB_Shell_1_MOP_0x8026988[];
extern Vtx VB_Shell_1_MOP_0x8026a18[];
extern Vtx VB_Shell_1_MOP_0x8026b08[];
extern Vtx VB_Shell_1_MOP_0x8026bf8[];
extern Vtx VB_Shell_1_MOP_0x8026ce8[];
extern Vtx VB_Shell_1_MOP_0x8026dd8[];
extern Vtx VB_Shell_1_MOP_0x8026ec8[];
extern Vtx VB_Shell_1_MOP_0x8026fb8[];
extern Vtx VB_Shell_1_MOP_0x80270a8[];
extern const Light_t Light_Shell_1_MOP_0x80263a8;
extern const Light_t Light_Shell_1_MOP_0x80263c0;
extern const Light_t Light_Shell_1_MOP_0x80263d8;
extern const Ambient_t Light_Shell_1_MOP_0x80263a0;
extern const Ambient_t Light_Shell_1_MOP_0x80263b8;
extern const Ambient_t Light_Shell_1_MOP_0x80263d0;
extern const Gfx DL_Shell_1_MOP_0x8027420[];
extern const Gfx DL_Shell_1_MOP_0x8027108[];
extern const Gfx DL_Shell_1_MOP_0x8027170[];
extern const Gfx DL_Shell_1_MOP_0x8027258[];
#endif