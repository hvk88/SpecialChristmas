-- Moving Textures (WaterBoxes)
--   Every movtext type is set to 1 (normal water texture)
--   If you want to configure and setup other water type, change the value here
movtexqc_register('bbh_1_Movtex_0', 4, 1, 0)
movtexqc_register('castle_inside_1_Movtex_0', 6, 1, 0)
movtexqc_register('jrb_1_Movtex_0', 12, 1, 0)
movtexqc_register('jrb_1_Movtex_1', 12, 1, 1)
movtexqc_register('wf_1_Movtex_0', 24, 1, 0)
movtexqc_register('wmotr_1_Movtex_0', 31, 1, 0)

-- Scroll Textures
--   Uncomment and replace <id>, <offset> and <count> with the proper values
--   if you want to have scroll textures in your mod.
--[[
add_scroll_target(<id>, "VB_bob_1_0x0", <offset>, <count>)
--]]
