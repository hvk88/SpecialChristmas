smlua_text_utils_dialog_replace(DIALOG_000,1,6,30,200, ("Wow! You're smack in the\
middle of the battlefield.\
You'll find the Power\
Stars that Bowser stole\
inside the painting\
worlds.\
First, talk to the\
Bob-omb Buddy. (Press [B]\
to talk.) He'll certainly\
help you out, and so will\
his comrades in other\
areas.\
To read signs, stop, face\
them and press [B]. Press [A]\
or [B] to scroll ahead. You\
can talk to some other\
characters by facing them\
and pressing [B]."))

smlua_text_utils_dialog_replace(DIALOG_001,1,4,95,200, ("Hi Mario!\
You finally woke up!\
Did you see what a\
beautiful Chrismas\
tree I have made?\
I had no clue what to\
put at the top, so\
I ended up using a real\
power star!\
Don't tell it to\
Peach..."))

smlua_text_utils_dialog_replace(DIALOG_002,1,4,95,200, ("Hey, you! It's dangerous\
ahead, so listen up! Take\
my advice.\
\
Cross the two\
bridges ahead, then\
watch for falling\
water bombs.\
The Big Bob-omb at the\
top of the mountain is\
very powerful--don't let\
him grab you!\
We're Bob-omb Buddies,\
and we're on your side.\
You can talk to us\
whenever you'd like to!"))

smlua_text_utils_dialog_replace(DIALOG_003,1,5,95,200, ("Thank you, Mario! The Big\
Bob-omb is nothing but a\
big dud now! But the\
battle for the castle has\
just begun.\
Other enemies are holding\
the other Power Stars. If\
you recover more Stars,\
you can open new doors\
that lead to new worlds!\
My Bob-omb Buddies are\
waiting for you. Be sure\
to talk to them--they'll\
set up cannons for you."))

smlua_text_utils_dialog_replace(DIALOG_004,1,3,95,200, ("We're peace-loving\
Bob-ombs, so we don't use\
cannons.\
But if you'd like\
to blast off, we don't\
mind. Help yourself.\
We'll prepare all of the\
cannons in this course for\
you to use. Bon Voyage!"))

smlua_text_utils_dialog_replace(DIALOG_005,1,3,30,200, ("Hey, Mario! Is it true\
that you beat the Big\
Bob-omb? Cool!\
You must be strong. And\
pretty fast. So, how fast\
are you, anyway?\
Fast enough to beat me...\
Koopa the Quick? I don't\
think so. Just try me.\
How about a race to the\
mountaintop, where the\
Big Bob-omb was?\
Whaddya say? When I say\
『Go,』 let the race begin!\
\
Ready....\
\
//Go!////Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_006,1,3,30,200, ("Hey!!! Don't try to scam\
ME. You've gotta run\
the whole course.\
Later. Look me up when\
you want to race for\
real."))

smlua_text_utils_dialog_replace(DIALOG_007,1,5,30,200, ("Hufff...fff...pufff...\
Whoa! You...really...are...\
fast! A human blur!\
Here you go--you've won\
it, fair and square!"))

smlua_text_utils_dialog_replace(DIALOG_008,1,4,30,200, ("BEWARE OF CHAIN CHOMP\
Extreme Danger!\
Get close and press [C]^\
for a better look.\
Scary, huh?\
See the Red Coin on top\
of the stake?\
\
When you collect eight of\
them, a Power Star will\
appear in the meadow\
across the bridge."))

smlua_text_utils_dialog_replace(DIALOG_009,1,5,30,200, ("Long time, no see! Wow,\
have you gotten fast!\
Have you been training\
on the sly, or is it the\
power of the Stars?\
I've been feeling down\
about losing the last\
race. This is my home\
course--how about a\
rematch?\
The goal is in\
Windswept Valley.\
Ready?\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_010,1,4,30,200, ("You've stepped on the\
Wing Cap Switch. Wearing\
the Wing Cap, you can\
soar through the sky.\
Now Wing Caps will pop\
out of all the red blocks\
you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_011,1,4,30,200, ("You've just stepped on\
the Metal Cap Switch!\
The Metal Cap makes\
Mario invincible.\
Now Metal Caps will\
pop out of all of the\
green blocks you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_012,1,4,30,200, ("You've just stepped on\
the Vanish Cap Switch.\
The Vanish Cap makes\
Mario disappear.\
Now Vanish Caps will pop\
from all of the blue\
blocks you find.\
\
Would you like to Save?\
\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_013,1,5,30,200, ("You've collected 100\
coins! Mario gains more\
power from the castle.\
Do you want to Save?\
//Yes////No"))

smlua_text_utils_dialog_replace(DIALOG_014,1,4,30,200, ("Wow! Another Power Star!\
Mario gains more courage\
from the power of the\
castle.\
Do you want to Save?\
\
//You Bet//Not Now"))

smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("You can punch enemies to\
knock them down. Press [A]\
to jump, [B] to punch.\
Press [A] then [B] to Kick.\
To pick something up,\
press [B], too. To throw\
something you're holding,\
press [B] again."))

smlua_text_utils_dialog_replace(DIALOG_016,1,3,30,200, ("Hop on the shiny shell and\
ride wherever you want to\
go! Shred those enemies!"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("I'm the Big Bob-omb, lord\
of all blasting matter,\
king of ka-booms the\
world over!\
How dare you scale my\
mountain? By what right\
do you set foot on my\
imperial mountaintop?\
You may have eluded my\
guards, but you'll never\
escape my grasp...\
\
...and you'll never take\
away my Power Star. I\
hereby challenge you,\
Mario!\
If you want the Star I\
hold, you must prove\
yourself in battle.\
\
Can you pick me up from\
the back and hurl me to\
this royal turf? I think\
that you cannot!"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("I'm sleeping because...\
...I'm sleepy. I don't\
like being disturbed.\
Please walk quietly."))

smlua_text_utils_dialog_replace(DIALOG_019,1,2,30,200, ("Shhh! Please walk\
quietly in the hallway!"))

smlua_text_utils_dialog_replace(DIALOG_020,1,6,95,150, ("Dear Mario:\
Please come to the\
castle. I've baked\
a cake for you.\
Yours truly--\
Princess Toadstool"))

smlua_text_utils_dialog_replace(DIALOG_021,1,5,95,200, ("Welcome.\
No one's home!\
Now scram--\
and don't come back!\
Gwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_022,1,2,95,200, ("You need a key to open\
this door."))

smlua_text_utils_dialog_replace(DIALOG_023,1,3,95,200, ("This key doesn't fit!\
Maybe it's for another\
door."))

smlua_text_utils_dialog_replace(DIALOG_024,1,5,95,200, ("You need Star power to\
open this door. Recover a\
Power Star from an enemy\
inside one of the castle's\
paintings."))

smlua_text_utils_dialog_replace(DIALOG_025,1,4,95,200, ("It takes the power of\
3 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_026,1,4,95,200, ("It takes the power of\
8 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_027,1,4,95,200, ("It takes the power of\
30 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_028,1,4,95,200, ("It takes the power of\
50 Stars to open this\
door. You need [%] more\
Stars."))

smlua_text_utils_dialog_replace(DIALOG_029,1,5,95,200, ("To open the door that\
leads to the 『endless』\
stairs, you need 70\
Stars.\
Bwa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_030,1,6,30,200, ("Hello! The Lakitu Bros.,\
cutting in with a live\
update on Mario's\
progress. He's about to\
learn a technique for\
sneaking up on enemies.\
The trick is this: He has\
to walk very slowly in\
order to walk quietly.\
\
\
\
And wrapping up filming\
techniques reported on\
earlier, you can take a\
look around using [C]> and\
[C]<. Press [C]| to view the\
action from a distance.\
When you can't move the\
camera any farther, the\
buzzer will sound. This is\
the Lakitu Bros.,\
signing off."))

smlua_text_utils_dialog_replace(DIALOG_031,1,5,30,200, ("No way! You beat me...\
again!! And I just spent\
my entire savings on\
these new Koopa\
Mach 1 Sprint shoes!\
Here, I guess I have to\
hand over this Star to\
the winner of the race.\
Congrats, Mario!"))

smlua_text_utils_dialog_replace(DIALOG_032,1,5,30,200, ("If you get the Wing Cap,\
you can fly! Put the cap\
on, then do a Triple\
Jump--jump three times\
in a row--to take off.\
You can fly even higher\
if you blast out of a\
cannon wearing the\
Wing Cap!\
\
Use the [C] Buttons to look\
around while flying, and\
press [Z] to land."))

smlua_text_utils_dialog_replace(DIALOG_033,1,6,30,200, ("Ciao! You've reached\
Princess Toadstool's\
castle via a warp pipe.\
Using the controller is a\
piece of cake. Press [A] to\
jump and [B] to attack.\
Press [B] to read signs,\
too. Use the Control Stick\
in the center of the\
controller to move Mario\
around. Now, head for\
the castle."))

smlua_text_utils_dialog_replace(DIALOG_034,1,6,30,200, ("Good afternoon. The\
Lakitu Bros., here,\
reporting live from just\
outside the Princess's\
castle.\
\
Mario has just arrived\
on the scene, and we'll\
be filming the action live\
as he enters the castle\
and pursues the missing\
Power Stars.\
As seasoned cameramen,\
we'll be shooting from the\
recommended angle, but\
you can change the\
camera angle by pressing\
the [C] Buttons.\
If we can't adjust the\
view any further, we'll\
buzz. To take a look at\
the surroundings, stop\
and press [C]^.\
\
Press [A] to resume play.\
Switch camera modes with\
the [R] Button. Signs along\
the way will review these\
instructions.\
\
For now, reporting live,\
this has been the\
Lakitu Bros."))

smlua_text_utils_dialog_replace(DIALOG_035,1,5,30,200, ("There are four camera, or\
『[C],』 Buttons. Press [C]^\
to look around using the\
Control Stick.\
\
You'll usually see Mario\
through Lakitu's camera.\
It is the camera\
recommended for normal\
play.\
You can change angles by\
pressing [C]>. If you press\
[R], the view switches to\
Mario's camera, which\
is directly behind him.\
Press [R] again to return\
to Lakitu's camera. Press\
[C]| to see Mario from\
afar, using either\
Lakitu's or Mario's view."))

smlua_text_utils_dialog_replace(DIALOG_036,1,5,30,200, ("OBSERVATION PLATFORM\
Press [C]^ to take a look\
around. Don't miss\
anything!\
\
Press [R] to switch to\
Mario's camera. It\
always follows Mario.\
Press [R] again to switch\
to Lakitu's camera.\
Pause the game and\
switch the mode to 『fix』\
the camera in place while\
holding [R]. Give it a try!"))

smlua_text_utils_dialog_replace(DIALOG_037,1,2,30,200, ("I win! You lose!\
Ha ha ha ha!\
You're no slouch, but I'm\
a better sledder!\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_038,1,3,95,200, ("Reacting to the Star\
power, the door slowly\
opens."))

smlua_text_utils_dialog_replace(DIALOG_039,1,4,30,200, ("No visitors allowed,\
by decree of\
the Big Bob-omb\
\
I shall never surrender my\
Stars, for they hold the\
power of the castle in\
their glow.\
They were a gift from\
Bowser, the Koopa King\
himself, and they lie well\
hidden within my realm.\
Not a whisper of their\
whereabouts shall leave\
my lips. Oh, all right,\
perhaps one hint:\
Heed the Star names at\
the beginning of the\
course.\
//--The Big Bob-omb"))

smlua_text_utils_dialog_replace(DIALOG_040,1,3,30,200, ("Warning!\
Cold, Cold Crevasse\
Below!"))

smlua_text_utils_dialog_replace(DIALOG_041,1,3,30,200, ("I win! You lose!\
Ha ha ha!\
\
That's what you get for\
messin' with Koopa the\
Quick.\
Better luck next time!"))

smlua_text_utils_dialog_replace(DIALOG_042,1,4,30,200, ("Caution! Narrow Bridge!\
Cross slowly!\
\
\
You can jump to the edge\
of the cliff and hang on,\
and you can climb off the\
edge if you move slowly.\
When you want to let go,\
either press [Z] or press\
the Control Stick in the\
direction of Mario's back.\
To climb up, press Up on\
the Control Stick. To\
scurry up quickly, press\
the [A] Button."))

smlua_text_utils_dialog_replace(DIALOG_043,1,5,30,200, ("If you jump and hold the\
[A] Button, you can hang on\
to some objects overhead.\
It's the same as grabbing\
a flying bird!"))

smlua_text_utils_dialog_replace(DIALOG_044,1,5,95,200, ("Whooo's there? Whooo\
woke me up? It's still\
daylight--I should be\
sleeping!\
\
Hey, as long as I'm\
awake, why not take a\
short flight with me?\
Press and hold [A] to grab\
on. Release [A] to let go.\
I'll take you wherever\
you want to go, as long\
as my wings hold out.\
Watch my shadow, and\
grab on."))

smlua_text_utils_dialog_replace(DIALOG_045,1,6,95,200, ("Whew! I'm just about\
flapped out. You should\
lay off the pasta, Mario!\
That's it for now. Press\
[A] to let go. Okay,\
bye byyyyyyeeee!"))

smlua_text_utils_dialog_replace(DIALOG_046,1,5,30,200, ("You have to master three\
important jumping\
techniques.\
First try the Triple Jump.\
\
Run fast, then jump three\
times, one, two, three.\
If you time the jumps\
right, you'll hop, skip,\
then jump really high.\
Next, go for distance\
with the Long Jump. Run,\
press [Z] to crouch then [A]\
to jump really far.\
\
To do the Wall Kick, press\
[A] to jump at a wall, then\
jump again when you hit\
the wall.\
\
Got that? Triple Jump,\
Long Jump, Wall Kick.\
Practice, practice,\
practice. You don't stand\
a chance without them."))

smlua_text_utils_dialog_replace(DIALOG_047,1,2,95,200, ("Hi! I'll prepare the\
cannon for you!"))

smlua_text_utils_dialog_replace(DIALOG_048,1,4,30,200, ("Snow Mountain Summit\
Watch for slippery\
conditions! Please enter\
the cottage first."))

smlua_text_utils_dialog_replace(DIALOG_049,1,5,30,200, ("Remember that tricky Wall\
Kick jump? It's a\
technique you'll have to\
master in order to reach\
high places.\
Use it to jump from wall\
to wall. Press the\
Control Stick in the\
direction you want to\
bounce to gain momentum.\
Practice makes perfect!"))

smlua_text_utils_dialog_replace(DIALOG_050,1,4,30,200, ("Hold [Z] to crouch and\
slide down a slope.\
Or press [Z] while in the\
air to Pound the Ground!\
If you stop, crouch, then\
jump, you'll do a\
Backward Somersault!\
Got that?\
There's more. Crouch and\
then jump to do a\
Long Jump! Or crouch and\
walk to...never mind."))

smlua_text_utils_dialog_replace(DIALOG_051,1,6,30,200, ("Hey... it seems that\
those piranha plants\
are sleeping. \
Try to perform a long\
jump on their heads!"))

smlua_text_utils_dialog_replace(DIALOG_052,1,5,30,200, ("Stop and press [Z] to\
crouch, then press [A]\
to do a high, Backward\
Somersault!\
\
To perform a Side\
Somersault, run, do a\
sharp U-turn and jump.\
You can catch lots of\
air with both jumps."))

smlua_text_utils_dialog_replace(DIALOG_053,1,5,30,200, ("Sometimes, if you pass\
through a coin ring or\
find a secret point in a\
course, a red number will\
appear.\
If you trigger five red\
numbers, a secret Star\
will show up."))

smlua_text_utils_dialog_replace(DIALOG_054,1,5,30,200, ("Welcome to the snow\
slide! Hop on! To speed\
up, press forward on the\
Control Stick. To slow\
down, pull back."))

smlua_text_utils_dialog_replace(DIALOG_055,1,4,30,200, ("Hey-ey, Mario, buddy,\
howzit goin'? Step right\
up. You look like a fast\
sleddin' kind of guy.\
I know speed when I see\
it, yes siree--I'm the\
world champion sledder,\
you know. Whaddya say?\
How about a race?\
Ready...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_056,1,6,30,200, ("You brrrr-oke my record!\
Unbelievable! I knew\
that you were the coolest.\
Now you've proven\
that you're also the\
fastest!\
I can't award you a gold\
medal, but here, take this\
Star instead. You've\
earned it!"))

smlua_text_utils_dialog_replace(DIALOG_057,1,4,30,200, ("Egad! My baby!! Have you\
seen my baby??? She's\
the most precious baby in\
the whole wide world.\
(They say she has my\
beak...) I just can't\
remember where I left\
her.\
Let's see...I stopped\
for herring and ice cubes,\
then I...oohh! I just\
don't know!"))

smlua_text_utils_dialog_replace(DIALOG_058,1,4,30,200, ("You found my precious,\
precious baby! Where\
have you been? How can\
I ever thank you, Mario?\
Oh, I do have this...\
...Star. Here, take it\
with my eternal\
gratitude."))

smlua_text_utils_dialog_replace(DIALOG_059,1,4,30,200, ("That's not my baby! She\
looks nothing like me!\
Her parents must be\
worried sick!"))

smlua_text_utils_dialog_replace(DIALOG_060,1,4,30,200, ("ATTENTION!\
Read Before Diving In!\
\
\
If you stay under the\
water for too long, you'll\
run out of oxygen.\
\
Return to the surface for\
air or find an air bubble\
or coins to breathe while\
underwater.\
Press [A] to swim. Hold [A]\
to swim slow and steady.\
Tap [A] with smooth timing\
to gain speed.\
Press Up on the\
Control Stick and press [A]\
to dive.\
\
Press Down on the Control\
Stick and press [A] to\
return to the surface.\
\
Hold Down and press [A]\
while on the surface near\
the edge of the water to\
jump out."))

smlua_text_utils_dialog_replace(DIALOG_061,1,4,30,200, ("BRRR! Frostbite Danger!\
Do not swim here.\
I'm serious.\
/--The Penguin"))

smlua_text_utils_dialog_replace(DIALOG_062,1,3,30,200, ("Hidden inside the green\
block is the amazing\
Metal Cap.\
Wearing it, you won't\
catch fire or be hurt\
by enemy attacks.\
You don't even have to\
breathe while wearing it.\
\
The only problem:\
You can't swim in it."))

smlua_text_utils_dialog_replace(DIALOG_063,1,5,30,200, ("The Vanish Cap is inside\
the blue block. Mr. I.\
will be surprised, since\
you'll be invisible when\
you wear it!\
Even the Big Boo will be\
fooled--and you can walk\
through secret walls, too."))

smlua_text_utils_dialog_replace(DIALOG_064,1,5,30,200, ("When you put on the Wing\
Cap that comes from a\
red block, do the Triple\
Jump to soar high into\
the sky.\
Use the Control Stick to\
guide Mario. Pull back to\
to fly up, press forward\
to nose down, and press [Z]\
to land."))

smlua_text_utils_dialog_replace(DIALOG_065,1,6,30,200, ("~ CREDITS ~\
\
Toad's Tool 64\
&\
Level Importer:\
VL-Tone\
Messiaen (Frauber)\
Skelux\
\
Special thank to\
Kazeshin\
for all the help\
he gave me on\
the forum.\
\
Thank you for\
playing!\
\
Kinopio - DeathMaskX"))

smlua_text_utils_dialog_replace(DIALOG_066,1,5,30,200, ("Mario, it's Peach!\
Please be careful! Bowser\
is so wicked! He will try\
to burn you with his\
horrible flame breath.\
Run around behind and\
grab him by the tail with\
the [B] Button. Once you\
grab hold, swing him\
around in great circles.\
Rotate the Control Stick\
to go faster and faster.\
The faster you swing him,\
the farther he'll fly.\
\
Use the [C] Buttons to look\
around, Mario. You have\
to throw Bowser into one\
of the bombs in the four\
corners.\
Aim well, then press [B]\
again to launch Bowser.\
Good luck, Mario! Our\
fate is in your hands."))

smlua_text_utils_dialog_replace(DIALOG_067,1,5,30,200, ("Ah ah, now that you\
can sense the third\
dimension everything\
looks so different,\
isn't it true?\
It's incredible how\
much fun we could have\
with just two buttons\
and a d-pad...\
Come on!\
Show me how much your\
skills are improved!"))

smlua_text_utils_dialog_replace(DIALOG_068,1,5,30,200, ("It's Lethal Lava Land!\
If you catch fire or fall\
into a pool of flames,\
you'll be hopping mad, but\
don't lose your cool.\
You can still control\
Mario--just try to keep\
calm!"))

smlua_text_utils_dialog_replace(DIALOG_069,1,6,30,200, ("Sometimes you'll bump into\
invisible walls at the\
edges of the painting\
worlds. If you hit a wall\
while flying, you'll bounce\
back."))

smlua_text_utils_dialog_replace(DIALOG_070,1,5,30,200, ("You can return to the\
castle's main hall at any\
time from the painting\
worlds where the enemies\
live.\
Just stop, stand still,\
press Start to pause the\
game, then select\
『Exit Course.』\
\
You don't have to collect\
all Power Stars in one\
course before going on to\
the next.\
\
Return later, when you're\
more experienced, to pick\
up difficult ones.\
\
\
Whenever you find a Star,\
a hint for finding the\
next one will appear on\
the course's start screen.\
\
You can, however, collect\
any of the remaining\
Stars next. You don't\
have to recover the one\
described by the hint."))

smlua_text_utils_dialog_replace(DIALOG_071,1,3,30,200, ("Danger Ahead!\
Beware of the strange\
cloud! Don't inhale!\
If you feel faint, run for\
higher ground and fresh\
air!\
Circle: Shelter\
Arrow: Entrance-Exit"))

smlua_text_utils_dialog_replace(DIALOG_072,1,5,30,200, ("High winds ahead!\
Pull your Cap down tight.\
If it blows off, you'll\
have to find it on this\
mountain."))

smlua_text_utils_dialog_replace(DIALOG_073,1,4,95,200, ("Aarrgh! Ahoy, matey. I\
have sunken treasure,\
here, I do.\
\
But to pluck the plunder,\
you must open the\
Treasure Chests in the\
right order.\
What order is that,\
ye say?\
\
\
I'll never tell!\
\
//--The Cap'n"))

smlua_text_utils_dialog_replace(DIALOG_074,1,5,30,200, ("You can grab on to the\
edge of a cliff or ledge\
with your fingertips and\
hang down from it.\
\
To drop from the edge,\
either press the Control\
Stick in the direction of\
Mario's back or press the\
[Z] Button.\
To get up onto the ledge,\
either press Up on the\
Control Stick or press [A]\
as soon as you grab the\
ledge to climb up quickly."))

smlua_text_utils_dialog_replace(DIALOG_075,1,5,30,200, ("Mario!! My castle is in\
great peril. I know that\
Bowser is the cause...and\
I know that only you can\
stop him!\
The doors in the castle\
that have been sealed by\
Bowser can be opened only\
with Star Power.\
\
But there are secret\
paths in the castle,\
paths that Bowser hasn't\
found.\
\
One of those paths is in\
this room, and it holds\
one of the castle's Secret\
Stars!\
\
Find that Secret Star,\
Mario! It will help you\
on your quest. Please,\
Mario, you have to\
help us!\
Retrieve all of the\
Power Stars in the castle\
and free us from this\
awful prison!\
Please!"))

smlua_text_utils_dialog_replace(DIALOG_076,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting. Oh, by the\
way, look what I found!"))

smlua_text_utils_dialog_replace(DIALOG_077,1,2,150,200, ("It is decreed that one\
shall pound the pillars."))

smlua_text_utils_dialog_replace(DIALOG_078,1,5,30,200, ("Break open the Blue Coin\
Block by Pounding the\
Ground with the [Z] Button.\
One Blue Coin is worth\
five Yellow Coins.\
But you have to hurry!\
The coins will disappear\
if you're not quick to\
collect them! Too bad."))

smlua_text_utils_dialog_replace(DIALOG_079,1,4,30,200, ("Owwwuu! Let me go!\
Uukee-kee! I was only\
teasing! Can't you take\
a joke?\
I'll tell you what, let's\
trade. If you let me go,\
I'll give you something\
really good.\
So, how about it?\
\
//Free him/ Hold on"))

smlua_text_utils_dialog_replace(DIALOG_080,1,1,30,200, ("Eeeh hee hee hee!"))

smlua_text_utils_dialog_replace(DIALOG_081,1,4,30,200, ("The mystery is of Wet\
or Dry.\
And where does the\
solution lie?\
The city welcomes visitors\
with the depth they bring\
as they enter."))

smlua_text_utils_dialog_replace(DIALOG_082,1,4,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
injured easily.\
\
If you do lose your Cap,\
you'll have to find it in\
the course where you\
lost it.\
Oh, boy, it's not looking\
good for Peach. She's\
still trapped somewhere\
inside the walls.\
Please, Mario, you have\
to help her! Did you know\
that there are enemy\
worlds inside the walls?\
Yup. It's true. Bowser's\
troops are there, too.\
Oh, here, take this. I've\
been keeping it for you."))

smlua_text_utils_dialog_replace(DIALOG_083,1,6,30,200, ("There's something strange\
about that clock. As you\
jump inside, watch the\
position of the big hand.\
Oh, look what I found!\
Here, Mario, catch!"))

smlua_text_utils_dialog_replace(DIALOG_084,1,3,30,200, ("Yeeoww! Unhand me,\
brute! I'm late, so late,\
I must make haste!\
This shiny thing? Mine!\
It's mine. Finders,\
keepers, losers...\
Late, late, late...\
Ouch! Take it then! A\
gift from Bowser, it was.\
Now let me be! I have a\
date! I cannot be late\
for tea!"))

smlua_text_utils_dialog_replace(DIALOG_085,1,5,30,200, ("You don't stand a ghost\
of a chance in this house.\
If you walk out of here,\
you deserve...\
...a Ghoul Medal..."))

smlua_text_utils_dialog_replace(DIALOG_086,1,3,30,200, ("Running around in circles\
makes some bad guys roll\
their eyes."))

smlua_text_utils_dialog_replace(DIALOG_087,1,4,30,200, ("Santa Claus isn't the only\
one who can go down a\
chimney! Come on in!\
/--Cabin Proprietor"))

smlua_text_utils_dialog_replace(DIALOG_088,1,5,30,200, ("Work Elevator\
For those who get off\
here: Grab the pole to the\
left and slide carefully\
down."))

smlua_text_utils_dialog_replace(DIALOG_089,1,5,95,200, ("Both ways fraught with\
danger! Watch your feet!\
Those who can't do the\
Long Jump, tsk, tsk. Make\
your way to the right.\
Right: Work Elevator\
/// Cloudy Maze\
Left: Black Hole\
///Underground Lake\
\
Red Circle: Elevator 2\
//// Underground Lake\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_090,1,6,30,200, ("Bwa ha ha ha!\
You've stepped right into\
my trap, just as I knew\
you would! I warn you,\
『Friend,』 watch your\
step!"))

smlua_text_utils_dialog_replace(DIALOG_091,2,2,30,200, ("Danger!\
Strong Gusts!\
But the wind makes a\
comfy ride."))

smlua_text_utils_dialog_replace(DIALOG_092,1,5,30,200, ("Bwawawawa!\
It took only to move\
some platform and\
make same little\
change to make\
everything harder!\
This time you\
won't succeed!"))

smlua_text_utils_dialog_replace(DIALOG_093,1,5,30,200, ("Did you see how\
you will become?!\
People will have to\
shake their arms\
to make you jump\
higher!\
This is just\
ridiculous...\
Kids nowadays no more\
like jumping between\
platforms inside\
colorful worlds.\
They prefer cool things\
as shooting and playing\
at war!\
Mario, you are old now.\
There is no place for\
you in the future!!"))

smlua_text_utils_dialog_replace(DIALOG_094,1,4,30,200, ("Get a good run up the\
slope! Do you remember\
the Long Jump? Run, press\
[Z], then jump!"))

smlua_text_utils_dialog_replace(DIALOG_095,1,4,30,200, ("To read a sign, stand in\
front of it and press [B],\
like you did just now.\
\
When you want to talk to\
a Koopa Troopa or other\
animal, stand right in\
front of it.\
Please recover the Stars\
that were stolen by\
Bowser in this course."))

smlua_text_utils_dialog_replace(DIALOG_096,1,4,30,200, ("The path is narrow here.\
Easy does it! No one is\
allowed on top of the\
mountain!\
And if you know what's\
good for you, you won't\
wake anyone who's\
sleeping!\
Move slowly,\
tread lightly."))

smlua_text_utils_dialog_replace(DIALOG_097,1,5,30,200, ("Don't be a pushover!\
If anyone tries to shove\
you around, push back!\
It's one-on-one, with a\
fiery finish for the loser!"))

smlua_text_utils_dialog_replace(DIALOG_098,1,2,95,200, ("Come on in here...\
...heh, heh, heh..."))

smlua_text_utils_dialog_replace(DIALOG_099,1,5,95,200, ("Buu... Buu... Mario!\
Don't you recognize me?!\
Did you forget about me?!\
...I came back to warn\
you!\
Tonight you are going\
to meet three ghosts:\
The ghost of the Christmas\
Past, Present and Future.\
Each door will lead you\
to one of them, but be\
careful! Danger awaits\
you.\
...Bwahahahah!"))

smlua_text_utils_dialog_replace(DIALOG_100,1,3,95,200, ("Ukkiki...Wakkiki...kee kee!\
Ha! I snagged it!\
It's mine! Heeheeheeee!"))

smlua_text_utils_dialog_replace(DIALOG_101,1,3,95,200, ("Ackk! Let...go...\
You're...choking...me...\
Cough...I've been framed!\
This Cap? Oh, all right,\
take it. It's a cool Cap,\
but I'll give it back.\
I think it looks better on\
me than it does on you,\
though! Eeeee! Kee keee!"))

smlua_text_utils_dialog_replace(DIALOG_102,1,5,30,200, ("Pssst! The Boos are super\
shy. If you look them\
in the eyes, they fade\
away, but if you turn\
your back, they reappear.\
It's no use trying to hit\
them when they're fading\
away. Instead, sneak up\
behind them and punch."))

smlua_text_utils_dialog_replace(DIALOG_103,1,4,95,200, ("Upon four towers\
one must alight...\
Then at the peak\
shall shine the light..."))

smlua_text_utils_dialog_replace(DIALOG_104,1,5,30,200, ("The shadowy star in front\
of you is a 『Star\
Marker.』 When you collect\
all 8 Red Coins, the Star\
will appear here."))

smlua_text_utils_dialog_replace(DIALOG_105,1,3,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!\
\
You can reach the Star on\
the floating island by\
using the four cannons.\
Use the Control Stick to\
aim, then press [A] to fire.\
\
If you're handy, you can\
grab on to trees or poles\
to land."))

smlua_text_utils_dialog_replace(DIALOG_106,1,2,95,200, ("Ready for blastoff! Come\
on, hop into the cannon!"))

smlua_text_utils_dialog_replace(DIALOG_107,1,3,95,200, ("...Mario!\
\
Stanotte incontrerai\
i 3 fantasmi:\
\
Del Passato, Presente\
e Futuro.\
"))

smlua_text_utils_dialog_replace(DIALOG_108,1,2,95,200, ("Boooooo-m! Here comes\
the master of mischief,\
the tower of terror,\
the Big Boo!\
Ka ha ha ha..."))

smlua_text_utils_dialog_replace(DIALOG_109,1,4,95,200, ("Ooooo Nooooo!\
Talk about out-of-body\
experiences--my body\
has melted away!\
Have you run in to any\
headhunters lately??\
I could sure use a new\
body!\
Brrr! My face might\
freeze like this!"))

smlua_text_utils_dialog_replace(DIALOG_110,1,5,95,200, ("I need a good head on my\
shoulders. Do you know of\
anybody in need of a good\
body? Please! I'll follow\
you if you do!"))

smlua_text_utils_dialog_replace(DIALOG_111,1,4,95,200, ("Perfect! What a great\
new body! Here--this is a\
present for you. It's sure\
to warm you up."))

smlua_text_utils_dialog_replace(DIALOG_112,1,4,30,200, ("Collect as many coins as\
possible! They'll refill\
your Power Meter.\
\
You can check to see how\
many coins you've\
collected in each of the\
15 enemy worlds.\
You can also recover\
power by touching the\
Spinning Heart.\
\
The faster you run\
through the heart, the\
more power you'll recover."))

smlua_text_utils_dialog_replace(DIALOG_113,1,6,30,200, ("There are special Caps in\
the red, green and blue\
blocks. Step on the\
switches in the hidden\
courses to activate the\
Cap Blocks."))

smlua_text_utils_dialog_replace(DIALOG_114,1,5,95,200, ("It makes me so mad! We\
build your houses, your\
castles. We pave your\
roads, and still you\
walk all over us.\
Do you ever say thank\
you? No! Well, you're not\
going to wipe your feet\
on me! I think I'll crush\
you just for fun!\
Do you have a problem\
with that? Just try to\
pound me, wimp! Ha!"))

smlua_text_utils_dialog_replace(DIALOG_115,1,5,95,200, ("No! Crushed again!\
I'm just a stepping stone,\
after all. I won't gravel,\
er, grovel. Here, you win.\
Take this with you!"))

smlua_text_utils_dialog_replace(DIALOG_116,1,5,95,200, ("Whaaa....Whaaat?\
Can it be that a\
pipsqueak like you has\
defused the Bob-omb\
king????\
You might be fast enough\
to ground me, but you'll\
have to pick up the pace\
if you want to take King\
Bowser by the tail.\
Methinks my troops could\
learn a lesson from you!\
Here is your Star, as I\
promised, Mario.\
\
If you want to see me\
again, select this Star\
from the menu. For now,\
farewell."))

smlua_text_utils_dialog_replace(DIALOG_117,1,1,95,200, ("Who...walk...here?\
Who...break...seal?\
Wake..ancient..ones?\
We no like light...\
Rrrrummbbble...\
We no like...intruders!\
Now battle...\
...hand...\
...to...\
...hand!"))

smlua_text_utils_dialog_replace(DIALOG_118,1,6,95,200, ("Grrrrumbbble!\
What...happen?\
We...crushed like pebble.\
You so strong!\
You rule ancient pyramid!\
For today...\
Now, take Star of Power.\
We...sleep...darkness."))

smlua_text_utils_dialog_replace(DIALOG_119,1,6,30,200, ("Ugh...\
Now you are a lot\
stronger.\
Take this key.\
It opens the next\
door."))

smlua_text_utils_dialog_replace(DIALOG_120,1,4,30,200, ("No... you beat me\
also this time...\
This key open the\
last of the three\
doors.\
The hardest challege\
awaits you!!"))

smlua_text_utils_dialog_replace(DIALOG_121,1,5,30,200, ("Ouch!\
Well done...\
You managed to defeat me,\
the last of the tree\
ghosts.\
It's true... \
times has changed,\
but you can still bring\
joy and happiness.\
This is what really\
matters.\
Now go!\
Christmas awaits you!"))

smlua_text_utils_dialog_replace(DIALOG_122,1,4,30,200, ("The Black Hole\
Right: Work Elevator\
/// Cloudy Maze\
Left: Underground Lake"))

smlua_text_utils_dialog_replace(DIALOG_123,1,4,30,200, ("Metal Cavern\
Right: To Waterfall\
Left: Metal Cap Switch"))

smlua_text_utils_dialog_replace(DIALOG_124,1,4,30,200, ("Work Elevator\
Danger!!\
Read instructions\
thoroughly!\
Elevator continues in the\
direction of the arrow\
activated."))

smlua_text_utils_dialog_replace(DIALOG_125,1,3,30,200, ("Hazy Maze-Exit\
Danger! Closed.\
Turn back now."))

smlua_text_utils_dialog_replace(DIALOG_126,2,3,30,200, ("Up: Black Hole\
Right: Work Elevator\
/// Hazy Maze"))

smlua_text_utils_dialog_replace(DIALOG_127,3,4,30,200, ("Underground Lake\
Right: Metal Cave\
Left: Abandoned Mine\
///(Closed)\
A gentle sea dragon lives\
here. Pound on his back to\
make him lower his head.\
Don't become his lunch."))

smlua_text_utils_dialog_replace(DIALOG_128,1,4,95,200, ("You must fight with\
honor! It is against the\
royal rules to throw the\
king out of the ring!"))

smlua_text_utils_dialog_replace(DIALOG_129,1,5,30,200, ("Welcome to the Vanish\
Cap Switch Course! All of\
the blue blocks you find\
will become solid once you\
step on the Cap Switch.\
You'll disappear when you\
put on the Vanish Cap, so\
you'll be able to elude\
enemies and walk through\
many things. Try it out!"))

smlua_text_utils_dialog_replace(DIALOG_130,1,5,30,200, ("Welcome to the Metal Cap\
Switch Course! Once you\
step on the Cap Switch,\
the green blocks will\
become solid.\
When you turn your body\
into metal with the Metal\
Cap, you can walk\
underwater! Try it!"))

smlua_text_utils_dialog_replace(DIALOG_131,1,5,30,200, ("Welcome to the Wing Cap\
Course! Step on the red\
switch at the top of the\
tower, in the center of\
the rainbow ring.\
When you trigger the\
switch, all of the red\
blocks you find will\
become solid.\
\
Try out the Wing Cap! Do\
the Triple Jump to take\
off and press [Z] to land.\
\
\
Pull back on the Control\
Stick to go up and push\
forward to nose down,\
just as you would when\
flying an airplane."))

smlua_text_utils_dialog_replace(DIALOG_132,1,4,30,200, ("Whoa, Mario, pal, you\
aren't trying to cheat,\
are you? Shortcuts aren't\
allowed.\
Now, I know that you\
know better. You're\
disqualified! Next time,\
play fair!"))

smlua_text_utils_dialog_replace(DIALOG_133,1,6,30,200, ("Oh, Mario!\
You woke up late this\
morning, isn't it true?\
What? You had a bad\
dream?!\
Fortunately now you\
are ok and you can\
celebrate Christmas\
with us!\
Merry Christmas!! ★"))

smlua_text_utils_dialog_replace(DIALOG_134,1,5,30,200, ("Look at all those gifts!\
They are so many!\
I couldn't resist, so\
last night I have already\
opened one... eh eh"))

smlua_text_utils_dialog_replace(DIALOG_135,1,5,30,200, ("Ugh!\
Snow it's so beautiful,\
but it was up to me to\
clear all the path to\
the castle. It was very\
tiring...\
Also the small lake nearby\
is completely frozen."))

smlua_text_utils_dialog_replace(DIALOG_136,1,6,30,200, ("Wow! You've already\
recovered that many\
Stars? Way to go, Mario!\
I'll bet you'll have us out\
of here in no time!\
\
Be careful, though.\
Bowser and his band\
wrote the book on 『bad.』\
Take my advice: When you\
need to recover from\
injuries, collect coins.\
Yellow Coins refill one\
piece of the Power Meter,\
Red Coins refill two\
pieces, and Blue Coins\
refill five.\
\
To make Blue Coins\
appear, pound on Blue\
Coin Blocks.\
\
\
\
Also, if you fall from\
high places, you'll\
minimize damage if you\
Pound the Ground as you\
land."))

smlua_text_utils_dialog_replace(DIALOG_137,1,6,30,200, ("You have finally arrived!\
I am faint with hunger,\
but we couldn't start\
eating without you.\
I can't wait to eat\
spaghetti and ravioli!\
Peach has also baked a\
delicious cake!\
yum! yum!"))

smlua_text_utils_dialog_replace(DIALOG_138,1,3,30,200, ("Down: Underground Lake\
Left: Black Hole\
Right: Hazy Maze (Closed)"))

smlua_text_utils_dialog_replace(DIALOG_139,1,6,30,200, ("Above: Automatic Elevator\
Elevator begins\
automatically and follows\
pre-set course.\
It disappears\
automatically, too."))

smlua_text_utils_dialog_replace(DIALOG_140,1,6,30,200, ("Elevator Area\
Right: Hazy Maze\
/// Entrance\
Left: Black Hole\
///Elevator 1\
Arrow: You are here"))

smlua_text_utils_dialog_replace(DIALOG_141,1,5,150,200, ("You've recovered one of\
the three Power Stars!\
Collect all the red\
coins in a level to\
earn other stars."))

smlua_text_utils_dialog_replace(DIALOG_142,1,5,150,200, ("Good!\
You have collected\
all the three secret\
power stars. ★ ★ ★"))

smlua_text_utils_dialog_replace(DIALOG_143,1,6,150,200, ("You've recovered eight of\
the Power Stars! Now you\
can open the door with\
the big Star! But Bowser\
is just ahead...can you\
hear the Princess calling?"))

smlua_text_utils_dialog_replace(DIALOG_144,1,6,150,200, ("You've recovered 30\
Power Stars! Now you can\
open the door with the\
big Star! But before you\
move on, how's it going\
otherwise?\
Did you pound the two\
columns down? You didn't\
lose your hat, did you?\
If you did, you'll have to\
stomp on the condor to\
get it back!\
They say that Bowser has\
sneaked out of the sea\
and into the underground.\
Have you finally\
cornered him?"))

smlua_text_utils_dialog_replace(DIALOG_145,1,6,150,200, ("You've recovered 50\
Power Stars! Now you can\
open the Star Door on the\
third floor. Bowser's\
there, you know.\
\
Oh! You've found all of\
the Cap Switches, haven't\
you? Red, green and blue?\
The Caps you get from the\
colored blocks are really\
helpful.\
Hurry along, now. The\
third floor is just ahead."))

smlua_text_utils_dialog_replace(DIALOG_146,1,6,150,200, ("You've found 70 Power\
Stars! The mystery of the\
endless stairs is solved,\
thanks to you--and is\
Bowser ever upset! Now,\
on to the final bout!"))

smlua_text_utils_dialog_replace(DIALOG_147,1,5,30,200, ("Are you using the Cap\
Blocks? You really should,\
you know.\
\
\
To make them solid so you\
can break them, you have\
to press the colored Cap\
Switches in the castle's\
hidden courses.\
You'll find the hidden\
courses only after\
regaining some of the\
Power Stars.\
\
The Cap Blocks are a big\
help! Red for the Wing\
Cap, green for the Metal\
Cap, blue for the Vanish\
Cap."))

smlua_text_utils_dialog_replace(DIALOG_148,1,6,30,200, ("Snowman Mountain ahead.\
Keep out! And don't try\
the Triple Jump over the\
ice block shooter.\
\
\
If you fall into the\
freezing pond, your power\
decreases quickly, and\
you won't recover\
automatically.\
//--The Snowman"))

smlua_text_utils_dialog_replace(DIALOG_149,1,3,30,200, ("Welcome to\
Princess Toadstool's\
secret slide!\
There's a Star hidden\
here that Bowser couldn't\
find.\
When you slide, press\
forward to speed up,\
pull back to slow down.\
If you slide really\
fast, you'll win the Star!"))

smlua_text_utils_dialog_replace(DIALOG_150,1,5,30,200, ("Waaaa! You've flooded my\
house! Wh-why?? Look at\
this mess! What am I\
going to do now?\
\
The ceiling's ruined, the\
floor is soaked...what to\
do, what to do? Huff...\
huff...it makes me so...\
MAD!!!\
Everything's been going\
wrong ever since I got\
this Star...It's so shiny,\
but it makes me feel...\
strange..."))

smlua_text_utils_dialog_replace(DIALOG_151,1,4,30,200, ("I can't take this\
anymore! First you get\
me all wet, then you\
stomp on me!\
Now I'm really, really,\
REALLY mad!\
Waaaaaaaaaaaaaaaaa!!!"))

smlua_text_utils_dialog_replace(DIALOG_152,1,3,30,200, ("Owwch! Uncle! Uncle!\
Okay, I give. Take this\
Star!\
Whew! I feel better now.\
I don't really need it\
anymore, anyway--\
I can see the stars\
through my ceiling at\
night.\
They make me feel...\
...peaceful. Please, come\
back and visit anytime."))

smlua_text_utils_dialog_replace(DIALOG_153,1,4,30,200, ("Hey! Who's there?\
What's climbing on me?\
Is it an ice ant?\
A snow flea?\
Whatever it is, it's\
bugging me! I think I'll\
blow it away!"))

smlua_text_utils_dialog_replace(DIALOG_154,1,5,30,200, ("Hold on to your hat! If\
you lose it, you'll be\
easily injured. If you\
lose it, look for it in the\
course where you lost it.\
Speaking of lost, the\
Princess is still stuck in\
the walls somewhere.\
Please help, Mario!\
\
Oh, you know that there\
are secret worlds in the\
walls as well as in the\
paintings, right?"))

smlua_text_utils_dialog_replace(DIALOG_155,1,6,30,200, ("Thanks to the power of\
the Stars, life is\
returning to the castle.\
Please, Mario, you have\
to give Bowser the boot!\
\
Here, let me tell you a\
little something about the\
castle. In the room with\
the mirrors, look carefully\
for anything that's not\
reflected in the mirror.\
And when you go to the\
water town, you can flood\
it with a high jump into\
the painting."))

smlua_text_utils_dialog_replace(DIALOG_156,1,5,30,200, ("The world inside the\
clock is so strange!\
When you jump inside,\
watch the position of\
the big hand!"))

smlua_text_utils_dialog_replace(DIALOG_157,1,5,30,200, ("Watch out! Don't let\
yourself be swallowed by\
quicksand.\
\
\
If you sink into the sand,\
you won't be able to\
jump, and if your head\
goes under, you'll be\
smothered.\
The dark areas are\
bottomless pits."))

smlua_text_utils_dialog_replace(DIALOG_158,1,6,30,200, ("1. If you jump repeatedly\
and time it right, you'll\
jump higher and higher.\
If you run really fast and\
time three jumps right,\
you can do a Triple Jump.\
2. Jump into a solid wall,\
then jump again when you\
hit the wall. You can\
bounce to a higher level\
using this Wall Kick."))

smlua_text_utils_dialog_replace(DIALOG_159,1,6,30,200, ("3. If you stop, press [Z]\
to crouch, then jump, you\
can perform a Backward\
Somersault. To do a Long\
Jump, run fast, press [Z],\
then jump."))

smlua_text_utils_dialog_replace(DIALOG_160,1,4,30,200, ("Press [B] while running\
fast to do a Body Slide\
attack. To stand while\
sliding, press [A] or [B]."))

smlua_text_utils_dialog_replace(DIALOG_161,1,4,30,200, ("Mario!!!\
It that really you???\
It has been so long since\
our last adventure!\
They told me that I might\
see you if I waited here,\
but I'd just about given\
up hope!\
Is it true? Have you\
really beaten Bowser? And\
restored the Stars to the\
castle?\
And saved the Princess?\
I knew you could do it!\
Now I have a very special\
message for you.\
『Thanks for playing Super\
Mario 64! This is the\
end of the game, but not\
the end of the fun.\
We want you to keep on\
playing, so we have a\
little something for you.\
We hope that you like it!\
Enjoy!!!』\
\
The Super Mario 64 Team"))

smlua_text_utils_dialog_replace(DIALOG_162,1,4,30,200, ("No, no, no! Not you\
again! I'm in a great\
hurry, can't you see?\
\
I've no time to squabble\
over Stars. Here, have it.\
I never meant to hide it\
from you...\
It's just that I'm in such\
a rush. That's it, that's\
all. Now, I must be off.\
Owww! Let me go!"))

smlua_text_utils_dialog_replace(DIALOG_163,1,5,30,200, ("Noooo! You've really\
beaten me this time,\
Mario! I can't stand\
losing to you!\
\
My troops...worthless!\
They've turned over all\
the Power Stars! What?!\
There are 120 in all???\
\
Amazing! There were some\
in the castle that I\
missed??!!\
\
\
Now I see peace\
returning to the world...\
Oooo! I really hate that!\
I can't watch--\
I'm outta here!\
Just you wait until next\
time. Until then, keep\
that Control Stick\
smokin'!\
Buwaa ha ha!"))

smlua_text_utils_dialog_replace(DIALOG_164,1,4,30,200, ("Mario! What's up, pal?\
I haven't been on the\
slide lately, so I'm out\
of shape.\
Still, I'm always up for a\
good race, especially\
against an old sleddin'\
buddy.\
Whaddya say?\
Ready...set...\
\
//Go//// Don't Go"))

smlua_text_utils_dialog_replace(DIALOG_165,1,5,30,200, ("I take no responsibility\
whatsoever for those who\
get dizzy and pass out\
from running around\
this post."))

smlua_text_utils_dialog_replace(DIALOG_166,1,4,30,200, ("I'll be back soon.\
I'm out training now,\
so come back later.\
//--Koopa the Quick"))

smlua_text_utils_dialog_replace(DIALOG_167,1,4,30,200, ("Kinopio - DeathmaskX\
\
Presents:\
\
★ SCROOGE 64 ★\
\
Enjoy your playing!"))

smlua_text_utils_dialog_replace(DIALOG_168,1,5,30,200, ("Hey! Knock it off! That's\
the second time you've\
nailed me. Now you're\
asking for it, linguine\
breath!"))

smlua_text_utils_dialog_replace(DIALOG_169,1,4,30,200, ("Keep out!\
That means you!\
Arrgghh!\
\
Anyone entering this cave\
without permission will\
meet certain disaster."))

