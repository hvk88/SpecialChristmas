smlua_text_utils_dialog_replace(DIALOG_015,1,4,30,200, ("C1"))

smlua_text_utils_dialog_replace(DIALOG_016,1,4,30,200, ("C2"))

smlua_text_utils_dialog_replace(DIALOG_017,1,4,30,200, ("NG"))

smlua_text_utils_dialog_replace(DIALOG_018,1,4,30,200, ("C3"))